import { Trophy, Medal, Flame, Zap, Star, ShieldAlert, Navigation, Verified } from 'lucide-react';
import { ArenaScore, UserProfile } from '../types';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function ArenaModule({ profile }: { profile: UserProfile | null }) {
  const leaderboard: ArenaScore[] = [
    { id: '1', userId: 'u1', displayName: 'KasunP', score: 12500, university: 'UOC', badges: ['MapKing', 'NightOwl'] },
    { id: '2', userId: 'u2', displayName: 'Sarah_M', score: 11200, university: 'UOC', badges: ['EarlyBird'] },
    { id: '3', userId: 'u3', displayName: 'Amila99', score: 10800, university: 'SLIIT', badges: ['Foodie'] },
    { id: '4', userId: 'u4', displayName: 'Dilini_R', score: 9500, university: 'UOM', badges: [] },
  ];

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-display font-black text-black leading-none tracking-tighter uppercase italic">Uni-Arena</h2>
          <p className="text-gray-400 font-medium mt-2">The ultimate campus hierarchy. Dominate or be forgotten.</p>
        </div>
        <div className="bg-emerald-500 text-white px-8 py-4 rounded-[2rem] shadow-[0_20px_40px_rgba(16,185,129,0.3)] flex items-center gap-4">
          <Trophy size={28} />
          <div className="text-left">
            <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Season 04</p>
            <p className="font-display font-black text-lg leading-tight uppercase italic">Live Ranking</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 space-y-10">
          <div className="bg-white rounded-[3rem] border border-gray-100 shadow-2xl overflow-hidden">
             <div className="bg-black p-12 text-white flex items-center justify-between relative overflow-hidden">
                <div className="relative z-10">
                  <p className="text-[10px] font-display font-black uppercase tracking-[0.4em] text-blue-500 mb-4">My Status</p>
                  <h4 className="text-5xl font-display font-black tracking-tighter uppercase italic leading-none">{profile?.displayName?.split(' ')[0].toUpperCase()}</h4>
                  <div className="flex items-center gap-6 mt-8">
                    <div>
                      <p className="text-3xl font-display font-black">1.2K</p>
                      <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mt-1">PRIDE SCORE</p>
                    </div>
                    <div className="w-px h-10 bg-white/10"></div>
                    <div>
                      <p className="text-3xl font-display font-black text-blue-500">#1244</p>
                      <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mt-1">GLOBAL RANK</p>
                    </div>
                  </div>
                </div>
                <div className="relative z-10 text-right">
                   <div className="w-24 h-24 rounded-[2rem] bg-blue-600 flex items-center justify-center text-4xl font-display font-black italic shadow-2xl">
                     {profile?.displayName?.[0]}
                   </div>
                </div>
                <div className="absolute top-[-50%] right-[-10%] w-64 h-64 bg-blue-600/20 rounded-full blur-3xl"></div>
             </div>
             
             <div className="p-8">
               <div className="space-y-4">
                 <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4 mb-6">Top Contenders</h3>
                 {leaderboard.map((member, i) => (
                   <motion.div 
                     whileHover={{ x: 10, backgroundColor: '#F9FAFB' }}
                     key={member.id} 
                     className="flex items-center gap-6 p-8 rounded-[2.5rem] border border-gray-50 transition-all cursor-pointer"
                   >
                     <div className={cn(
                       "w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-2xl font-display font-black italic shadow-xl",
                       i === 0 ? "bg-amber-400 text-amber-900" : 
                       i === 1 ? "bg-slate-300 text-slate-700" : 
                       "bg-orange-200 text-orange-900"
                     )}>
                       {i + 1}
                     </div>
                     <div className="flex-1">
                       <h5 className="text-xl font-display font-black text-black leading-tight uppercase italic">{member.displayName}</h5>
                       <p className="text-[10px] font-mono font-bold text-gray-400 mt-1 uppercase">{member.university} • Level {Math.floor(member.score/1000)}</p>
                     </div>
                     <div className="text-right">
                       <p className="text-2xl font-display font-black text-black leading-none">{member.score.toLocaleString()}</p>
                       <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest mt-1">PRIDE</p>
                     </div>
                   </motion.div>
                 ))}
               </div>
             </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-8">
           <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Missions Pool</h3>
           <div className="grid grid-cols-1 gap-6">
              <MissionCard 
                title="Line-Splitter" 
                reward="500 Pride" 
                desc="Place 3 Flash-Orders in a single day." 
                icon={<Flame className="text-orange-600" />} 
                color="bg-orange-50"
              />
              <MissionCard 
                title="Map Architect" 
                reward="800 Pride" 
                desc="Verify 5 crowdsourced locations." 
                icon={<Navigation className="text-blue-600" />} 
                color="bg-blue-50"
              />
              <MissionCard 
                title="Safety Guard" 
                reward="1.2K Pride" 
                desc="Upload 10 menu captures to the AI Guard." 
                icon={<ShieldAlert className="text-emerald-600" />} 
                color="bg-emerald-50"
              />
           </div>
        </div>
      </div>
    </div>
  );
}

function MissionCard({ title, reward, desc, icon, color }: any) {
  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className={cn("p-10 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden group", color)}
    >
       <div className="flex justify-between items-start mb-10 relative z-10">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
            {icon}
          </div>
          <div className="bg-black text-white px-5 py-2 rounded-xl text-[10px] font-display font-black uppercase tracking-widest leading-none">
            {reward}
          </div>
       </div>
       <div className="relative z-10">
         <h5 className="text-2xl font-display font-black text-black italic uppercase leading-tight mb-2">{title}</h5>
         <p className="text-sm text-gray-500 font-medium leading-relaxed">{desc}</p>
       </div>
    </motion.div>
  );
}

function QuestCard({ icon, title, points, color }: { icon: any, title: string, points: string, color: string }) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between group cursor-pointer hover:shadow-md transition-all">
      <div className="flex items-center gap-4">
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", color)}>
          {icon}
        </div>
        <h5 className="font-bold text-gray-900 text-sm">{title}</h5>
      </div>
      <span className="font-black text-emerald-500 text-sm">{points}</span>
    </div>
  );
}
