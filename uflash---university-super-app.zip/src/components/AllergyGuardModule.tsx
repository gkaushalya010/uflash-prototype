import { useState } from 'react';
import { ShieldAlert, Search, Loader2, CheckCircle2, XCircle, Info } from 'lucide-react';
import { UserProfile } from '../types';
import { analyzeIngredients, AllergyAnalysis } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export default function AllergyGuardModule({ profile }: { profile: UserProfile | null }) {
  const [ingredients, setIngredients] = useState('');
  const [analysis, setAnalysis] = useState<AllergyAnalysis | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!ingredients.trim() || !profile) return;
    setLoading(true);
    try {
      const result = await analyzeIngredients(ingredients, profile.allergyProfile);
      setAnalysis(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-display font-black text-black leading-none tracking-tighter uppercase italic">SafetyGuard</h2>
          <p className="text-gray-400 font-medium mt-2">AI-driven ingredient screening for your health node.</p>
        </div>
        <div className="w-20 h-20 bg-rose-600 text-white rounded-[1.5rem] flex items-center justify-center shadow-[0_20px_40px_rgba(225,29,72,0.3)] shrink-0">
          <ShieldAlert size={40} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-12">
          <div className="bg-white rounded-[3rem] p-12 border border-gray-100 shadow-2xl space-y-10 relative overflow-hidden">
            <div className="relative z-10">
              <label className="block text-[10px] font-display font-black text-gray-300 uppercase tracking-[0.4em] mb-4 ml-2">Input Raw Data (Ingredients List)</label>
              <textarea 
                value={ingredients}
                onChange={(e) => setIngredients(e.target.value)}
                placeholder="PASTE INGREDIENTS HERE... (e.g. MILK, NUTS, WHEAT)"
                className="w-full h-48 bg-gray-50 border-2 border-transparent rounded-[2rem] p-10 text-black font-display font-black text-2xl placeholder:text-gray-200 focus:border-blue-600 transition-all resize-none italic uppercase tracking-tight"
              />
            </div>

            <button 
              onClick={handleAnalyze}
              disabled={loading || !ingredients.trim()}
              className="w-full bg-black text-white rounded-[2rem] py-8 font-display font-black text-2xl shadow-xl hover:scale-[1.02] hover:bg-blue-600 transition-all flex items-center justify-center gap-6 disabled:opacity-30 disabled:cursor-not-allowed group relative z-10 active:scale-95"
            >
              {loading ? (
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" />
                  ANALYZING...
                </div>
              ) : (
                <>
                  <Search size={32} className="text-blue-500 group-hover:text-white transition-colors" />
                  INITIATE SAFETY SCAN
                </>
              )}
            </button>
            
            <div className="absolute bottom-[-10%] left-[-5%] w-64 h-64 bg-blue-600/5 rounded-full blur-3xl"></div>
          </div>
        </div>

        <div className="lg:col-span-12">
          <AnimatePresence mode="wait">
            {analysis && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -20 }}
                className={cn(
                  "rounded-[3.5rem] p-12 border-4 shadow-2xl relative overflow-hidden transition-colors",
                  analysis.isSafe 
                    ? "bg-emerald-600 border-emerald-500 text-white" 
                    : "bg-rose-600 border-rose-500 text-white"
                )}
              >
                <div className="flex flex-col md:flex-row items-start md:items-center gap-10 relative z-10">
                  <div className={cn(
                    "w-24 h-24 rounded-[2rem] flex items-center justify-center flex-shrink-0 shadow-2xl",
                    analysis.isSafe ? "bg-white text-emerald-600" : "bg-white text-rose-600"
                  )}>
                    {analysis.isSafe ? <CheckCircle2 size={56} /> : <XCircle size={56} />}
                  </div>
                  <div className="flex-1 space-y-4">
                    <h3 className="text-5xl font-display font-black tracking-tighter uppercase italic leading-none">
                      {analysis.isSafe ? "OPTIMAL FOR CONSUMPTION" : "THREAT DETECTED"}
                    </h3>
                    <p className="text-xl opacity-80 leading-relaxed font-medium max-w-2xl">{analysis.explanation}</p>
                    
                    {!analysis.isSafe && analysis.detectedAllergens.length > 0 && (
                      <div className="flex flex-wrap gap-3 mt-8">
                        {analysis.detectedAllergens.map((alg, i) => (
                          <span key={i} className="bg-white text-rose-600 px-6 py-2 rounded-xl text-sm font-display font-black uppercase tracking-widest italic">
                            {alg}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-white opacity-10 rounded-full blur-[120px]"></div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      
      {!profile?.allergyProfile.length && (
        <div className="bg-amber-50 rounded-[2rem] p-8 border border-amber-100 flex items-center justify-center gap-4 text-amber-900 shadow-sm">
          <Info size={24} />
          <p className="text-sm font-display font-black uppercase tracking-widest text-center">
            Critical: NODE INCOMPLETE. UPDATE YOUR <span className="text-blue-600 underline cursor-pointer" onClick={() => window.dispatchEvent(new CustomEvent('nav', { detail: 'profile' }))}>ALLERGY PROFILE</span>.
          </p>
        </div>
      )}
    </div>
  );
}
