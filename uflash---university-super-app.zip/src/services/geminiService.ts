import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface AllergyAnalysis {
  isSafe: boolean;
  detectedAllergens: string[];
  explanation: string;
}

export async function analyzeIngredients(ingredients: string, userAllergens: string[]): Promise<AllergyAnalysis> {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const prompt = `
    Analyze the following ingredients list for a person with these allergies: ${userAllergens.join(', ')}.
    Ingredients: ${ingredients}
    
    Determine if it is safe to eat. Return a JSON object with:
    - isSafe: boolean
    - detectedAllergens: string[] (list of allergens found from the user's specific allergy list)
    - explanation: string (brief explanation of the finding)
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isSafe: { type: Type.BOOLEAN },
            detectedAllergens: { type: Type.ARRAY, items: { type: Type.STRING } },
            explanation: { type: Type.STRING }
          },
          required: ["isSafe", "detectedAllergens", "explanation"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as AllergyAnalysis;
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return {
      isSafe: false,
      detectedAllergens: [],
      explanation: "Failed to analyze ingredients. Please proceed with caution."
    };
  }
}
