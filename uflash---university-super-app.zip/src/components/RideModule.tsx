import { Car, MapPin, Navigation, Clock, ShieldCheck, ChevronRight } from 'lucide-react';
import { UserProfile } from '../types';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { useState } from 'react';

export default function RideModule({ profile }: { profile: UserProfile | null }) {
  const [destination, setDestination] = useState('');
  const [searching, setSearching] = useState(false);

  const vehicles = [
    { type: 'Flash Buddy', price: 'LKR 120', time: '2 mins', icon: <Car size={24}/>, color: 'bg-blue-600' },
    { type: 'Flash Mini', price: 'LKR 250', time: '5 mins', icon: <Car size={24}/>, color: 'bg-emerald-600' },
    { type: 'Uni Shuttle', price: 'FREE', time: '12 mins', icon: <Car size={24}/>, color: 'bg-black' }
  ];

  const handleRequest = () => {
    setSearching(true);
    setTimeout(() => setSearching(false), 3000);
  };

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-display font-black text-black leading-none tracking-tighter uppercase italic">FlashRide</h2>
          <p className="text-gray-400 font-medium mt-2">Zero-friction campus logistics. Safety by PickMe.</p>
        </div>
        <div className="flex items-center gap-4 bg-emerald-50 px-8 py-4 rounded-[2rem] border border-emerald-100 shadow-sm text-emerald-600">
          <ShieldCheck size={28} />
          <div className="text-left leading-none uppercase">
            <p className="text-[10px] font-black tracking-widest opacity-80 mb-1">Status</p>
            <p className="font-display font-black text-lg italic">PERIMETER LOCKED</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-12">
          <div className="bg-black rounded-[4rem] p-16 text-white shadow-2xl relative overflow-hidden">
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="space-y-10">
                <div className="space-y-6">
                   <div className="flex items-start gap-8 group">
                      <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                        <Navigation size={28} className="text-blue-500" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <p className="text-[10px] text-white/40 uppercase font-display font-black tracking-[0.4em]">Origin Node</p>
                        <p className="text-3xl font-display font-black uppercase italic tracking-tighter">Current Campus Coords</p>
                      </div>
                   </div>
                   
                   <div className="w-1 h-12 bg-white/5 ml-8"></div>

                   <div className="flex items-start gap-8 group">
                      <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform border border-white/5 group-focus-within:border-blue-500 transition-colors">
                        <MapPin size={28} className="text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <p className="text-[10px] text-white/40 uppercase font-display font-black tracking-[0.4em]">Target Node</p>
                        <input 
                          type="text" 
                          value={destination}
                          onChange={(e) => setDestination(e.target.value)}
                          placeholder="INPUT DESTINATION..." 
                          className="w-full bg-transparent border-none p-0 text-3xl font-display font-black focus:ring-0 placeholder:text-white/10 uppercase italic tracking-tighter"
                        />
                      </div>
                   </div>
                </div>

                <button 
                  onClick={handleRequest}
                  disabled={!destination || searching}
                  className="w-full bg-blue-600 text-white rounded-[2.5rem] py-10 font-display font-black text-4xl shadow-[0_30px_60px_rgba(37,99,235,0.4)] hover:bg-blue-700 transition-all flex items-center justify-center gap-6 active:scale-95 disabled:opacity-30 uppercase italic"
                >
                  {searching ? (
                    <div className="flex items-center gap-6">
                      <div className="w-10 h-10 border-4 border-white border-t-transparent rounded-full animate-spin" />
                      PINGING...
                    </div>
                  ) : "IGNITE RIDE"}
                </button>
              </div>

              <div className="hidden md:block relative">
                 <div className="bg-white/5 backdrop-blur-2xl rounded-[3rem] p-10 border border-white/10 space-y-8">
                    <h3 className="text-xs font-display font-black uppercase tracking-[0.6em] text-white/20">Selected Unit Spec</h3>
                    <div className="flex items-center gap-6">
                       <div className="w-20 h-20 bg-blue-600 rounded-[2rem] flex items-center justify-center shadow-2xl">
                          <Car size={32} />
                       </div>
                       <div>
                          <p className="text-3xl font-display font-black italic uppercase leading-none">FL-BUDDY</p>
                          <p className="text-sm font-black text-blue-500 mt-2 tracking-widest uppercase">ALPHA UNIT</p>
                       </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="bg-white/10 p-6 rounded-2xl">
                          <p className="text-[10px] text-white/40 font-black uppercase tracking-widest mb-2">ETA</p>
                          <p className="text-2xl font-display font-black">2 MINS</p>
                       </div>
                       <div className="bg-white/10 p-6 rounded-2xl">
                          <p className="text-[10px] text-white/40 font-black uppercase tracking-widest mb-2">FARE</p>
                          <p className="text-2xl font-display font-black text-emerald-500">LKR 120</p>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
            
            <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px]"></div>
          </div>
        </div>

        <div className="lg:col-span-12 space-y-8">
           <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Alternative Deployments</h3>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {vehicles.map((v, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={v.type} 
                  whileHover={{ y: -10 }}
                  className="bg-white rounded-[3rem] p-10 border border-gray-100 shadow-sm flex flex-col justify-between group hover:shadow-2xl transition-all cursor-pointer relative overflow-hidden"
                >
                  <div className="flex justify-between items-start relative z-10">
                    <div className={cn("w-20 h-20 rounded-[2rem] flex items-center justify-center text-white shadow-2xl group-hover:scale-110 transition-transform", v.color)}>
                      {v.icon}
                    </div>
                    <div className="text-right">
                       <p className="text-3xl font-display font-black text-black leading-none uppercase italic">{v.price}</p>
                       <p className="text-[10px] font-black text-gray-400 mt-2 tracking-widest uppercase">Fixed Rate</p>
                    </div>
                  </div>
                  <div className="mt-12 relative z-10">
                    <h5 className="text-2xl font-display font-black text-black uppercase italic tracking-tighter leading-none">{v.type}</h5>
                    <p className="text-sm font-bold text-gray-400 mt-2 uppercase tracking-widest">{v.time} RESPONSE TIME</p>
                  </div>
                  <div className="absolute bottom-[-10%] right-[-10%] w-32 h-32 bg-gray-50 rounded-full blur-2xl group-hover:bg-blue-50 transition-colors"></div>
                </motion.div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
}
