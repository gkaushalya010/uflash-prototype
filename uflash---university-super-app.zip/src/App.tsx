/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  auth, db, OperationType, handleFirestoreError 
} from './lib/firebase';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut,
  User
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { 
  LayoutDashboard, 
  Utensils, 
  Navigation, 
  ShieldAlert, 
  Trophy, 
  User as UserIcon,
  LogOut,
  Car
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, MembershipType } from './types';
import { cn } from './lib/utils';

// Modules
import CanteenModule from './components/CanteenModule';
import MapModule from './components/MapModule';
import AllergyGuardModule from './components/AllergyGuardModule';
import ArenaModule from './components/ArenaModule';
import ProfileModule from './components/ProfileModule';
import RideModule from './components/RideModule';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        await fetchProfile(user.uid);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const fetchProfile = async (uid: string) => {
    const docRef = doc(db, 'users', uid);
    try {
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setProfile(docSnap.data() as UserProfile);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `users/${uid}`);
    }
  };

  const signIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const docRef = doc(db, 'users', user.uid);
      let docSnap;
      try {
        docSnap = await getDoc(docRef);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
      }
      
      if (docSnap && !docSnap.exists()) {
        const newProfile: UserProfile = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || 'Uni Student',
          uniCode: 'UNI-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
          membershipType: 'free',
          allergyProfile: [],
          createdAt: new Date().toISOString()
        };
        try {
          await setDoc(docRef, {
            ...newProfile,
            createdAt: serverTimestamp()
          });
          setProfile(newProfile);
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        }
      } else if (docSnap) {
        setProfile(docSnap.data() as UserProfile);
      }
    } catch (error) {
      console.error("Sign in error:", error);
    }
  };

  const handleLogout = () => signOut(auth);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            className="w-16 h-16 border-[6px] border-black border-t-transparent rounded-full mx-auto mb-6"
          />
          <p className="font-display font-black text-2xl uppercase tracking-tighter">UFlash Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0C0C0C] p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, rotate: -2 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          className="max-w-md w-full bg-[#1A1A1A] rounded-[3rem] p-12 text-center border border-white/10 shadow-2xl overflow-hidden relative"
        >
          <div className="relative z-10">
            <div className="w-24 h-24 bg-blue-600 text-white rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 shadow-[0_0_50px_rgba(37,99,235,0.4)]">
              <span className="text-5xl font-display font-black italic">U</span>
            </div>
            <h1 className="text-5xl font-display font-black text-white mb-4 tracking-tight leading-[0.9]">DIVE INTO<br/>UFLASH</h1>
            <p className="text-gray-400 mb-12 font-medium">The only app you need for campus life.</p>
            
            <button 
              onClick={signIn}
              className="w-full bg-white text-black rounded-[2rem] py-6 font-display font-black text-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-4 active:scale-95 shadow-xl"
            >
              Sign In with Uni
            </button>
            <p className="text-[10px] uppercase tracking-[0.3em] font-black text-white/30 mt-10">
              Verified & Secure / Uni-Code System
            </p>
          </div>
          
          <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-blue-600 rounded-full opacity-20 blur-[100px]"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-64 h-64 bg-magenta-600 rounded-full opacity-10 blur-[100px]"></div>
        </motion.div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard profile={profile} setActiveTab={setActiveTab} />;
      case 'canteen':
        return <CanteenModule profile={profile} />;
      case 'maps':
        return <MapModule profile={profile} />;
      case 'allergy':
        return <AllergyGuardModule profile={profile} />;
      case 'ride':
        return <RideModule profile={profile} />;
      case 'arena':
        return <ArenaModule profile={profile} />;
      case 'profile':
        return <ProfileModule profile={profile} onUpdate={fetchProfile} />;
      default:
        return <Dashboard profile={profile} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row h-screen overflow-hidden">
      {/* Desktop Sidebar */}
      <nav className="hidden md:flex flex-col w-72 bg-black text-white p-8">
        <div className="flex items-center gap-4 mb-14">
          <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center text-2xl font-display font-black italic">UF</div>
          <span className="text-3xl font-display font-black tracking-tighter">UFLASH</span>
        </div>
        
        <div className="flex-1 space-y-2">
          <NavItem icon={<LayoutDashboard size={24}/>} label="Pulse" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <NavItem icon={<Utensils size={24}/>} label="Canteens" active={activeTab === 'canteen'} onClick={() => setActiveTab('canteen')} />
          <NavItem icon={<Navigation size={24}/>} label="SmartMap" active={activeTab === 'maps'} onClick={() => setActiveTab('maps')} />
          <NavItem icon={<Car size={24}/>} label="FlashRide" active={activeTab === 'ride'} onClick={() => setActiveTab('ride')} />
          <NavItem icon={<ShieldAlert size={24}/>} label="Safety" active={activeTab === 'allergy'} onClick={() => setActiveTab('allergy')} />
          <NavItem icon={<Trophy size={24}/>} label="Arena" active={activeTab === 'arena'} onClick={() => setActiveTab('arena')} />
        </div>

        <div className="mt-auto space-y-3 pt-8 border-t border-white/10">
          <button 
            onClick={() => setActiveTab('profile')}
            className={cn(
              "flex items-center gap-4 w-full p-4 rounded-[1.5rem] transition-all font-display font-bold uppercase text-sm tracking-widest",
              activeTab === 'profile' ? "bg-white text-black" : "text-white/50 hover:bg-white/5 hover:text-white"
            )}
          >
            <UserIcon size={20} />
            Profile
          </button>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-4 w-full p-4 rounded-[1.5rem] text-rose-500 hover:bg-rose-500/10 transition-all font-display font-bold uppercase text-sm tracking-widest"
          >
            <LogOut size={20} />
            Exit
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 relative overflow-y-auto bg-white">
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md px-10 py-6 flex items-center justify-between border-b border-gray-100">
          <div>
            <h2 className="text-xs font-display font-black uppercase tracking-[0.4em] text-gray-300">{activeTab}</h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-right hidden sm:block">
              <p className="text-lg font-display font-black text-black leading-none">{profile?.displayName?.toUpperCase()}</p>
              <p className="text-[10px] font-mono font-bold text-blue-600 mt-1">{profile?.uniCode}</p>
            </div>
            <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center font-display font-black text-black">
              {profile?.displayName?.[0]}
            </div>
          </div>
        </header>

        <div className="px-10 py-10 h-full max-w-7xl mx-auto custom-scrollbar overflow-y-auto pb-32 md:pb-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-6 left-6 right-6 bg-black rounded-[2.5rem] shadow-[0_30px_60px_-12px_rgba(0,0,0,0.5)] z-50 flex justify-around items-center p-3">
        <MobileNavItem icon={<LayoutDashboard size={24}/>} active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
        <MobileNavItem icon={<Utensils size={24}/>} active={activeTab === 'canteen'} onClick={() => setActiveTab('canteen')} />
        <MobileNavItem icon={<Navigation size={24}/>} active={activeTab === 'maps'} onClick={() => setActiveTab('maps')} />
        <MobileNavItem icon={<ShieldAlert size={24}/>} active={activeTab === 'allergy'} onClick={() => setActiveTab('allergy')} />
        <MobileNavItem icon={<UserIcon size={24}/>} active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
      </nav>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-4 w-full p-4 rounded-[1.5rem] transition-all font-display font-bold uppercase text-sm tracking-widest",
        active 
          ? "bg-blue-600 text-white shadow-[0_10px_30px_rgba(37,99,235,0.3)]" 
          : "text-white/40 hover:bg-white/5 hover:text-white"
      )}
    >
      <span className={cn("transition-transform duration-300", active && "scale-110")}>{icon}</span>
      {label}
    </button>
  );
}

function MobileNavItem({ icon, active, onClick }: { icon: any, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "p-5 rounded-full transition-all",
        active ? "bg-blue-600 text-white scale-110" : "text-white/40"
      )}
    >
      {icon}
    </button>
  );
}

function Dashboard({ profile, setActiveTab }: { profile: UserProfile | null, setActiveTab: (t: string) => void }) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-12 pb-20 md:pb-0">
      {/* Hero Welcome */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-blue-600 rounded-[3rem] p-12 text-white relative overflow-hidden flex flex-col justify-between min-h-[340px]">
          <div className="relative z-10">
            <p className="font-display font-black text-blue-200 uppercase tracking-[0.3em] text-xs mb-4">Pulse Status / Active</p>
            <h3 className="text-7xl font-display font-black tracking-tighter leading-[0.8] mb-6">WHAT'S NEXT,<br/>{profile?.displayName?.split(' ')[0].toUpperCase()}?</h3>
            <p className="text-xl text-blue-100 max-w-sm mt-4 font-medium leading-relaxed">
              Serving efficiency since 8 AM today.
            </p>
          </div>
          
          <div className="relative z-10 flex gap-4 mt-8">
            <button 
              onClick={() => setActiveTab('canteen')}
              className="bg-white text-black px-10 py-5 rounded-[1.5rem] font-display font-black text-lg hover:scale-105 active:scale-95 transition-all"
            >
              ORDER NOW
            </button>
          </div>

          <div className="absolute top-[-20%] right-[-10%] w-96 h-96 bg-white/20 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[-10%] left-[20%] w-64 h-64 bg-blue-400 rounded-full blur-[100px] opacity-40"></div>
        </div>

        <div className="bg-black rounded-[3rem] p-10 text-white flex flex-col justify-between items-center text-center">
          <p className="font-display font-black text-white/30 uppercase tracking-[0.3em] text-xs">Campus Time</p>
          <div className="space-y-1 py-10">
             <h4 className="text-7xl font-display font-black tracking-[0.1em]">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</h4>
             <p className="text-blue-500 font-mono font-bold">{currentTime.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' }).toUpperCase()}</p>
          </div>
          <div className="flex gap-2">
            {[1,2,3,4,5].map(i => (
              <div key={i} className={cn("w-2 h-2 rounded-full", i <= 3 ? "bg-blue-600" : "bg-white/10")}></div>
            ))}
          </div>
        </div>
      </div>

      {/* Bento Grid */}
      <div className="space-y-6">
        <h3 className="text-sm font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Core Ecosystem</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
          <BentoCard 
            colSpan="col-span-2"
            rowSpan="row-span-2"
            icon={<Utensils size={40} />}
            title="FLASH-ORDER"
            desc="Skip the lines entirely."
            color="bg-[#F8F8F8] text-black"
            accent="text-orange-600 bg-orange-100"
            onClick={() => setActiveTab('canteen')}
          />
          <BentoCard 
            colSpan="col-span-2"
            rowSpan="row-span-1"
            icon={<Navigation size={32} />}
            title="SMARTMAP"
            desc="Crowdsourced GPS."
            color="bg-emerald-50 text-emerald-900"
            accent="text-emerald-600 bg-emerald-100"
            onClick={() => setActiveTab('maps')}
          />
          <BentoCard 
            colSpan="col-span-2"
            rowSpan="row-span-2"
            icon={<ShieldAlert size={40} />}
            title="SAFETY"
            desc="AI Allergy screening."
            color="bg-rose-50 text-rose-900"
            accent="text-rose-600 bg-rose-100"
            onClick={() => setActiveTab('allergy')}
          />
          <BentoCard 
            colSpan="col-span-2"
            rowSpan="row-span-1"
            icon={<Car size={32} />}
            title="FLASHRIDE"
            desc="PickMe integration."
            color="bg-blue-50 text-blue-900"
            accent="text-blue-600 bg-blue-100"
            onClick={() => setActiveTab('ride')}
          />
          <BentoCard 
            colSpan="col-span-4"
            rowSpan="row-span-1"
            icon={<Trophy size={32} />}
            title="UNI-ARENA"
            desc="Dominate the campus leaderboard and earn Pride Scores."
            color="bg-black text-white"
            accent="text-amber-400 bg-amber-400/20"
            onClick={() => setActiveTab('arena')}
          />
        </div>
      </div>
    </div>
  );
}

function BentoCard({ colSpan, rowSpan, icon, title, desc, color, accent, onClick }: any) {
  return (
    <motion.button 
      whileHover={{ y: -8, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "rounded-[2.5rem] p-10 text-left relative overflow-hidden transition-all shadow-sm hover:shadow-2xl border border-gray-100/10",
        colSpan, rowSpan, color
      )}
    >
      <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center mb-10 transition-transform group-hover:scale-110", accent)}>
        {icon}
      </div>
      <div className="space-y-4">
        <h4 className="text-2xl font-display font-black tracking-tight">{title}</h4>
        <p className="text-sm opacity-60 font-medium leading-relaxed">{desc}</p>
      </div>
    </motion.button>
  );
}
