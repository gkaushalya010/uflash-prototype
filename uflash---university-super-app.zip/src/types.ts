export type MembershipType = 'free' | 'student_pro' | 'staff_pro';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  uniCode: string;
  membershipType: MembershipType;
  allergyProfile: string[];
  createdAt: string;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  ingredients: string[];
  canteenId: string;
}

export interface Canteen {
  id: string;
  name: string;
  type: 'internal' | 'external';
  menu: MenuItem[];
}

export interface Order {
  id: string;
  userId: string;
  canteenId: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: 'pending' | 'preparing' | 'ready' | 'completed';
  queueToken: string;
  isPriority: boolean;
  createdAt: string;
}

export interface MapPoint {
  id: string;
  name: string;
  description: string;
  lat: number;
  lng: number;
  createdBy: string;
  verifiedBy: string[];
  status: 'pending' | 'verified';
  imageUrl?: string;
}

export interface ArenaScore {
  id: string;
  userId: string;
  displayName: string;
  score: number;
  university: string;
  badges: string[];
}
