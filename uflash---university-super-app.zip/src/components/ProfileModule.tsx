import { useState } from 'react';
import { UserProfile, MembershipType } from '../types';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { User, ShieldAlert, Award, CreditCard, ChevronRight, Check, X, Plus } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function ProfileModule({ profile, onUpdate }: { profile: UserProfile | null, onUpdate: (uid: string) => void }) {
  const [allergens, setAllergens] = useState(profile?.allergyProfile || []);
  const [isSaving, setIsSaving] = useState(false);
  
  const commonAllergens = ['Milk', 'Eggs', 'Peanuts', 'Tree Nuts', 'Soy', 'Wheat', 'Fish', 'Shellfish'];

  const toggleAllergen = (alg: string) => {
    setAllergens(prev => 
      prev.includes(alg) ? prev.filter(a => a !== alg) : [...prev, alg]
    );
  };

  const saveProfile = async () => {
    if (!profile) return;
    setIsSaving(true);
    try {
      const docRef = doc(db, 'users', profile.uid);
      await updateDoc(docRef, {
        allergyProfile: allergens
      });
      onUpdate(profile.uid);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${profile.uid}`);
    } finally {
      setIsSaving(false);
    }
  };

  const upgradeMembership = async (tier: MembershipType) => {
    if (!profile) return;
    try {
      const docRef = doc(db, 'users', profile.uid);
      await updateDoc(docRef, {
        membershipType: tier
      });
      onUpdate(profile.uid);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${profile.uid}`);
    }
  };

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-20">
      <div className="bg-black rounded-[4rem] p-16 text-white shadow-2xl relative overflow-hidden flex flex-col md:flex-row gap-12 items-center md:items-start group">
        <div className="w-48 h-48 bg-white/10 rounded-[3rem] flex items-center justify-center text-white border-4 border-white/5 shadow-2xl relative z-10 overflow-hidden group-hover:scale-105 transition-transform duration-500">
           <div className="absolute inset-0 bg-blue-600 opacity-20 group-hover:opacity-40 transition-opacity"></div>
           <User size={100} className="relative z-10 opacity-40" />
           <div className="absolute inset-0 flex items-center justify-center text-7xl font-display font-black italic select-none">
             {profile?.displayName?.[0]}
           </div>
        </div>
        <div className="text-center md:text-left space-y-6 flex-1 relative z-10">
          <div>
            <h2 className="text-6xl font-display font-black text-white leading-none tracking-tighter uppercase italic">{profile?.displayName}</h2>
            <div className="flex items-center justify-center md:justify-start gap-4 mt-4">
              <p className="text-blue-500 font-display font-black tracking-widest text-xl uppercase italic">#{profile?.uniCode}</p>
              <div className="h-1 w-12 bg-white/10 rounded-full"></div>
              <p className="text-white/40 font-mono font-bold uppercase tracking-widest">Level 12 Operations</p>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center md:justify-start gap-6">
             <div className="bg-white/5 py-4 px-8 rounded-2xl border border-white/10 flex items-center gap-4 hover:bg-white/10 transition-colors">
               <ShieldAlert size={24} className="text-rose-500" />
               <div className="text-left leading-none">
                 <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">Health Guard</p>
                 <p className="font-display font-black text-lg italic uppercase">{profile?.allergyProfile.length || 0} Triggers</p>
               </div>
             </div>
             <div className="bg-white/5 py-4 px-8 rounded-2xl border border-white/10 flex items-center gap-4 hover:bg-white/10 transition-colors">
               <Award size={24} className="text-amber-500" />
               <div className="text-left leading-none">
                 <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">Tier Status</p>
                 <p className="font-display font-black text-lg italic uppercase">{profile?.membershipType?.replace('_', ' ')}</p>
               </div>
             </div>
          </div>
        </div>
        <div className="absolute top-[-50%] right-[-10%] w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px]"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-white rounded-[3.5rem] p-12 border border-solid border-gray-100 shadow-2xl space-y-10">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-3xl font-display font-black text-black leading-none uppercase italic tracking-tighter">Health Node</h3>
            <button 
              onClick={saveProfile}
              disabled={isSaving}
              className="bg-black text-white px-8 py-3 rounded-2xl font-display font-black text-xs uppercase tracking-widest hover:bg-blue-600 transition-all active:scale-95 disabled:opacity-30"
            >
              {isSaving ? "Syncing..." : "Sync Node"}
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {commonAllergens.map(alg => (
              <button 
                key={alg}
                onClick={() => toggleAllergen(alg)}
                className={cn(
                  "p-8 rounded-[2rem] border-2 text-lg font-display font-black transition-all text-left flex items-center justify-between group uppercase italic tracking-tight",
                  allergens.includes(alg) 
                    ? "bg-rose-600 border-rose-500 text-white shadow-xl scale-105" 
                    : "bg-gray-50 border-transparent text-gray-400 hover:bg-gray-100"
                )}
              >
                {alg}
                {allergens.includes(alg) ? <Check size={20} /> : <Plus size={20} className="opacity-10 group-hover:opacity-40" />}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Access Upgrade</h3>
          <div className="space-y-6">
             <TierCard 
               title="Student Pro" 
               price="LKR 300 / sem" 
               active={profile?.membershipType === 'student_pro'} 
               onSelect={() => upgradeMembership('student_pro')}
               perks={['Unlock All Nodes', 'SafetyGuard AI+', 'Priority Flash-Queue']}
             />
             <TierCard 
               title="Staff Elite" 
               price="LKR 500 / sem" 
               active={profile?.membershipType === 'staff_pro'} 
               onSelect={() => upgradeMembership('staff_pro')}
               perks={['Full Feature Access', 'Administrative Pings', 'Enterprise Dashboard']}
             />
          </div>
          
          <div className="bg-gray-50 rounded-[2.5rem] p-10 border border-gray-100 flex items-center justify-between group cursor-pointer hover:bg-black hover:text-white transition-all shadow-sm">
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-display font-black tracking-widest text-blue-500">Node Payment</p>
              <div className="flex items-center gap-6 mt-1">
                 <div className="flex items-center gap-4">
                    <CreditCard size={28} />
                    <span className="text-2xl font-display font-black italic uppercase">Visa Node 4242</span>
                 </div>
              </div>
            </div>
            <ChevronRight size={32} className="text-gray-300 group-hover:text-blue-500 transition-all group-hover:translate-x-2" />
          </div>
        </div>
      </div>
    </div>
  );
}

function TierCard({ title, price, active, onSelect, perks }: any) {
  return (
    <div className={cn(
      "rounded-[3rem] p-10 border-4 transition-all relative overflow-hidden group",
      active ? "bg-black border-blue-600 text-white shadow-2xl" : "bg-white border-gray-100 text-black hover:border-blue-100"
    )}>
      <div className="flex justify-between items-start mb-8 relative z-10">
        <div>
           <h4 className="text-4xl font-display font-black italic uppercase italic tracking-tighter leading-none">{title}</h4>
           <p className={cn("text-lg font-black mt-2 uppercase tracking-widest", active ? "text-blue-500" : "text-gray-300")}>{price}</p>
        </div>
        {active ? (
          <div className="bg-blue-600 text-white p-3 rounded-2xl shadow-xl"><Check size={28} /></div>
        ) : (
          <button 
            onClick={onSelect} 
            className="bg-gray-50 text-black px-6 py-3 rounded-2xl text-[10px] uppercase font-display font-black tracking-widest hover:bg-black hover:text-white transition-all shadow-sm"
          >
            Deploy
          </button>
        )}
      </div>
      
      <div className="space-y-3 relative z-10">
        {perks.map((p: any, i: any) => (
          <div key={i} className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest opacity-80">
            <Check size={16} className={active ? "text-blue-500" : "text-emerald-500"} />
            {p}
          </div>
        ))}
      </div>
      
      {active && (
        <div className="absolute top-[-20%] right-[-10%] w-48 h-48 bg-blue-600/20 rounded-full blur-3xl"></div>
      )}
    </div>
  );
}
