import { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { Canteen, MenuItem, Order, UserProfile } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Utensils, ShoppingBag, Clock, CheckCircle, Flame, Plus, Minus } from 'lucide-react';
import { cn } from '../lib/utils';

export default function CanteenModule({ profile }: { profile: UserProfile | null }) {
  // ... (previous state)
  const [canteens] = useState<Canteen[]>([
    {
      id: 'internal-1',
      name: 'MAIN CAMPUS CANTEEN',
      type: 'internal',
      menu: [
        { id: 'm1', name: 'Rice & Curry', price: 150, ingredients: ['rice', 'chicken', 'dal', 'coconut'], canteenId: 'internal-1' },
        { id: 'm2', name: 'Fried Rice', price: 180, ingredients: ['rice', 'egg', 'carrot', 'leeks'], canteenId: 'internal-1' },
        { id: 'm3', name: 'Kottu Roti', price: 200, ingredients: ['flour', 'chicken', 'egg', 'onion'], canteenId: 'internal-1' },
      ]
    },
    {
      id: 'external-1',
      name: 'NIMAL’S HOME KITCHEN',
      type: 'external',
      menu: [
        { id: 'e1', name: 'String Hoppers', price: 120, ingredients: ['flour', 'coconut'], canteenId: 'external-1' },
        { id: 'e2', name: 'Hoppers', price: 100, ingredients: ['rice flour', 'coconut milk'], canteenId: 'external-1' },
      ]
    }
  ]);

  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  const [selectedCanteen, setSelectedCanteen] = useState<Canteen | null>(null);
  const [cart, setCart] = useState<{ [key: string]: number }>({});
  const [isPriority, setIsPriority] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const q = query(
      collection(db, 'orders'), 
      where('userId', '==', profile.uid),
      orderBy('createdAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setActiveOrders(orders);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'orders');
    });
    return () => unsubscribe();
  }, [profile]);

  const addToCart = (item: MenuItem) => {
    setCart(prev => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }));
  };

  const removeFromCart = (item: MenuItem) => {
    if (!cart[item.id]) return;
    const newCart = { ...cart };
    if (newCart[item.id] === 1) delete newCart[item.id];
    else newCart[item.id]--;
    setCart(newCart);
  };

  const placeOrder = async () => {
    if (!profile || !selectedCanteen) return;
    
    const items = Object.entries(cart).map(([id, quantity]) => {
      const item = selectedCanteen.menu.find(m => m.id === id);
      return {
        name: item?.name || 'Unknown',
        quantity,
        price: item?.price || 0
      };
    });

    const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0) + (isPriority ? 20 : 0);

    try {
      await addDoc(collection(db, 'orders'), {
        userId: profile.uid,
        canteenId: selectedCanteen.id,
        items,
        total,
        status: 'pending',
        queueToken: 'TK-' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        isPriority,
        createdAt: serverTimestamp()
      });
      setCart({});
      setSelectedCanteen(null);
      setIsPriority(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
    }
  };

  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-10 max-w-6xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-5xl font-display font-black text-black leading-none tracking-tighter">FLASH-ORDER</h2>
          <p className="text-gray-400 font-medium mt-2">Skip the lines, feed the soul.</p>
        </div>
        <div className="flex items-center gap-3 bg-black text-white px-6 py-3 rounded-2xl shadow-xl">
          <ShoppingBag size={20} className="text-blue-500" />
          <span className="font-display font-bold text-sm uppercase tracking-widest">{activeOrders.length} ACTIVE ORDERS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 space-y-8">
          <AnimatePresence mode="wait">
            {!selectedCanteen ? (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                {canteens.map(canteen => (
                  <button 
                    key={canteen.id}
                    onClick={() => setSelectedCanteen(canteen)}
                    className="group bg-white rounded-[2.5rem] p-10 border border-gray-100 shadow-sm hover:shadow-2xl transition-all text-left flex flex-col justify-between min-h-[220px]"
                  >
                    <div className={cn(
                      "w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110",
                      canteen.type === 'internal' ? "bg-orange-50 text-orange-600" : "bg-emerald-50 text-emerald-600"
                    )}>
                      <Utensils size={32} />
                    </div>
                    <div>
                      <h4 className="text-2xl font-display font-black text-black leading-tight mb-1">{canteen.name}</h4>
                      <p className="text-xs font-black text-gray-300 uppercase tracking-widest">{canteen.type} CANTEEN</p>
                    </div>
                  </button>
                ))}
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-white rounded-[3rem] border border-gray-100 overflow-hidden shadow-2xl"
              >
                <div className="p-10 border-b border-gray-100 flex items-center justify-between bg-gray-50/30">
                  <button onClick={() => setSelectedCanteen(null)} className="font-display font-black text-sm text-blue-600 hover:scale-110 transition-transform tracking-widest uppercase">← Back</button>
                  <h4 className="text-2xl font-display font-black text-black">{selectedCanteen.name}</h4>
                  <div className="w-10"></div>
                </div>
                <div className="p-4 space-y-2">
                  {selectedCanteen.menu.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-6 rounded-[2rem] hover:bg-gray-50 transition-all group">
                      <div>
                        <h5 className="text-xl font-display font-black text-black group-hover:text-blue-600 transition-colors uppercase italic">{item.name}</h5>
                        <p className="text-sm font-mono font-bold text-gray-400 mt-1">LKR {item.price}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        {cart[item.id] > 0 && (
                          <>
                            <button onClick={() => removeFromCart(item)} className="w-12 h-12 rounded-2xl border-2 border-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition-all">
                              <Minus size={20} />
                            </button>
                            <span className="text-xl font-display font-black text-black w-6 text-center">{cart[item.id]}</span>
                          </>
                        )}
                        <button onClick={() => addToCart(item)} className="w-12 h-12 rounded-2xl bg-black text-white flex items-center justify-center hover:bg-blue-600 transition-all shadow-xl active:scale-95">
                          <Plus size={20} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {totalItems > 0 && (
                  <div className="p-10 border-t border-gray-100 bg-white">
                    <div 
                      className={cn(
                        "flex items-center justify-between mb-8 p-6 rounded-[2rem] transition-all cursor-pointer group",
                        isPriority ? "bg-orange-600 text-white shadow-[0_20px_40px_rgba(234,88,12,0.3)]" : "bg-gray-50 text-gray-900 border border-gray-100"
                      )} 
                      onClick={() => setIsPriority(!isPriority)}
                    >
                      <div className="flex items-center gap-5">
                        <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg", isPriority ? "bg-white text-orange-600" : "bg-white text-orange-600")}>
                          <Flame size={24} />
                        </div>
                        <div>
                          <p className="font-display font-black text-lg leading-tight">FLASH-QUEUE (PRO)</p>
                          <p className={cn("text-[10px] font-bold uppercase tracking-widest", isPriority ? "text-orange-200" : "text-gray-400")}>Skip the line for LKR 20</p>
                        </div>
                      </div>
                      <div className={cn("w-8 h-8 rounded-full border-4 flex items-center justify-center transition-all", isPriority ? "bg-white border-white" : "border-gray-200")}>
                        {isPriority && <CheckCircle size={16} className="text-orange-600" />}
                      </div>
                    </div>
                    
                    <button 
                      onClick={placeOrder}
                      className="w-full bg-blue-600 text-white rounded-[2rem] py-6 font-display font-black text-xl shadow-[0_20px_50px_rgba(37,99,235,0.4)] hover:scale-[1.02] hover:bg-blue-700 transition-all flex items-center justify-center gap-4 active:scale-95"
                    >
                      SEND IT • LKR {Object.entries(cart).reduce((acc, [id, q]) => acc + (selectedCanteen.menu.find(m => m.id === id)?.price || 0) * q, 0) + (isPriority ? 20 : 0)}
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="lg:col-span-4 space-y-8">
          <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Live Track</h3>
          {activeOrders.length === 0 ? (
            <div className="bg-white rounded-[3rem] p-12 text-center border-2 border-dashed border-gray-100 flex flex-col items-center justify-center min-h-[300px]">
              <Clock className="w-16 h-16 text-gray-100 mb-6" />
              <p className="font-display font-black text-gray-200 text-xl uppercase tracking-tighter italic">Crave something?<br/>Order now.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {activeOrders.map(order => (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  key={order.id} 
                  className="bg-black rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl border border-white/5"
                >
                  <div className="flex justify-between items-start mb-8 relative z-10">
                    <div>
                      <h5 className="font-display font-black text-lg tracking-tight leading-none uppercase italic">{canteens.find(c => c.id === order.canteenId)?.name}</h5>
                      <p className="text-[10px] font-mono font-bold text-gray-500 mt-2">{new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                    <div className="bg-blue-600 text-white px-4 py-1.5 rounded-full text-[10px] font-display font-black uppercase tracking-widest">
                      {order.status}
                    </div>
                  </div>
                  
                  <div className="bg-white/5 rounded-[2rem] p-8 mb-8 text-center border border-white/5 relative z-10 backdrop-blur-sm">
                    <p className="text-[10px] uppercase text-gray-500 font-black tracking-[0.2em] mb-2">My Ticket</p>
                    <p className="text-6xl font-display font-black text-white tracking-widest">{order.queueToken}</p>
                  </div>
                  
                  <div className="space-y-2 mb-2 relative z-10">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-bold text-gray-400">
                        <span>{item.quantity}× {item.name}</span>
                        <span className="text-white">LKR {item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {order.isPriority && (
                    <div className="absolute top-[-10%] right-[-10%] w-32 h-32 bg-orange-600/20 rounded-full blur-3xl"></div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
