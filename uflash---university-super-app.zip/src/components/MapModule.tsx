import { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  addDoc, 
  updateDoc,
  doc,
  arrayUnion,
  serverTimestamp 
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { MapPoint, UserProfile } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Navigation, Plus, MapPin, CheckCircle, Info, X } from 'lucide-react';
import { cn } from '../lib/utils';

export default function MapModule({ profile }: { profile: UserProfile | null }) {
  const [points, setPoints] = useState<MapPoint[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newPoint, setNewPoint] = useState({ name: '', description: '' });

  useEffect(() => {
    const q = query(collection(db, 'locations'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setPoints(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MapPoint)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'locations');
    });
    return () => unsubscribe();
  }, []);

  const handleAdd = async () => {
    if (!profile || !newPoint.name) return;
    try {
      await addDoc(collection(db, 'locations'), {
        name: newPoint.name,
        description: newPoint.description,
        lat: 6.9022 + (Math.random() - 0.5) * 0.01,
        lng: 79.8601 + (Math.random() - 0.5) * 0.01,
        createdBy: profile.uid,
        verifiedBy: [],
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setIsAdding(false);
      setNewPoint({ name: '', description: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'locations');
    }
  };

  const handleVerify = async (point: MapPoint) => {
    if (!profile || point.verifiedBy.includes(profile.uid)) return;
    const docRef = doc(db, 'locations', point.id);
    const updatedVerified = [...point.verifiedBy, profile.uid];
    const isVerified = updatedVerified.length >= 3;
    
    try {
      await updateDoc(docRef, {
        verifiedBy: arrayUnion(profile.uid),
        status: isVerified ? 'verified' : 'pending'
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `locations/${point.id}`);
    }
  };

  return (
    <div className="space-y-10 max-w-6xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-display font-black text-black leading-none tracking-tighter uppercase italic">SmartMap</h2>
          <p className="text-gray-400 font-medium mt-2">Crowdsourced campus navigation & intelligence.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-black text-white px-8 py-5 rounded-[2rem] shadow-xl flex items-center gap-4 font-display font-black text-lg hover:scale-105 transition-all active:scale-95 group"
        >
          <Plus size={24} className="text-blue-500 group-hover:rotate-90 transition-transform" />
          DROP A PIN
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="bg-gray-50 rounded-[3rem] aspect-[4/3] relative overflow-hidden flex items-center justify-center border border-gray-100 shadow-2xl group cursor-crosshair">
            <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:32px_32px]"></div>
            
            <div className="relative z-10 text-center p-12 bg-white/80 backdrop-blur-xl rounded-[3rem] border border-white/50 max-w-sm shadow-[0_30px_60px_-12px_rgba(0,0,0,0.1)]">
              <div className="w-16 h-16 bg-blue-600 rounded-[1.5rem] flex items-center justify-center text-white mx-auto mb-6 animate-pulse shadow-[0_0_40px_rgba(37,99,235,0.3)]">
                <Navigation size={32} />
              </div>
              <p className="text-2xl font-display font-black text-black leading-tight mb-2 italic uppercase tracking-tighter">GRID ACTIVE</p>
              <p className="text-sm text-gray-400 font-medium leading-relaxed">
                Map synchronized with <span className="text-blue-600 font-black">{points.length} Live Pins</span>.
              </p>
            </div>
            
            {points.map((p) => (
              <motion.div 
                key={p.id}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                style={{ 
                  position: 'absolute', 
                  left: `${((p.lng - 79.85) / 0.02) * 100}%`, 
                  top: `${((p.lat - 6.89) / 0.02) * 100}%` 
                }}
                className={cn(
                  "p-3 rounded-full cursor-pointer hover:scale-125 transition-transform shadow-2xl z-20 group/pin",
                  p.status === 'verified' ? "bg-blue-600 text-white" : "bg-black text-white"
                )}
              >
                <MapPin size={20} />
                <div className="absolute top-full mt-4 left-1/2 -translate-x-1/2 opacity-0 group-hover/pin:opacity-100 transition-all pointer-events-none">
                  <div className="bg-black text-white px-4 py-2 rounded-xl whitespace-nowrap shadow-2xl">
                    <p className="font-display font-black text-xs uppercase tracking-widest">{p.name}</p>
                    <p className="text-[10px] text-blue-400 font-bold mt-1 uppercase italic">{p.status}</p>
                  </div>
                </div>
              </motion.div>
            ))}

            <div className="absolute bottom-10 left-10 right-10 flex bg-white/70 backdrop-blur-xl border border-white/20 rounded-[2rem] p-6 shadow-xl z-30">
               <div className="flex-1 flex gap-6">
                 <div className="flex items-center gap-3">
                   <div className="w-3 h-3 rounded-full bg-blue-600"></div>
                   <span className="text-[10px] font-black uppercase tracking-widest text-black">Verified</span>
                 </div>
                 <div className="flex items-center gap-3">
                   <div className="w-3 h-3 rounded-full bg-black"></div>
                   <span className="text-[10px] font-black uppercase tracking-widest text-black/40">Pending</span>
                 </div>
               </div>
               <p className="text-[10px] font-mono font-bold text-gray-400">NODE: CM-ALPHA-01</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-8 overflow-y-auto max-h-[600px] px-2 custom-scrollbar pr-4">
          <h3 className="text-xs font-display font-black uppercase tracking-[0.5em] text-gray-300 ml-4">Hotspots Feed</h3>
          
          <AnimatePresence>
            {isAdding && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-black rounded-[2.5rem] p-10 shadow-2xl space-y-6 mb-8 text-white relative overflow-hidden"
              >
                <div className="flex justify-between items-center relative z-10">
                  <h4 className="text-2xl font-display font-black uppercase italic italic">Pin Location</h4>
                  <button onClick={() => setIsAdding(false)} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all">
                    <X size={20} />
                  </button>
                </div>
                <div className="space-y-4 relative z-10">
                  <input 
                    autoFocus
                    placeholder="NAME THE SPOT..."
                    value={newPoint.name}
                    onChange={(e) => setNewPoint({ ...newPoint, name: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-lg font-display font-black placeholder:text-white/20 focus:outline-none focus:border-blue-500 transition-all uppercase italic"
                  />
                  <textarea 
                    placeholder="WHY IS IT RELEVANT?"
                    value={newPoint.description}
                    onChange={(e) => setNewPoint({ ...newPoint, description: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-sm font-medium placeholder:text-white/20 focus:outline-none focus:border-blue-500 transition-all h-32 resize-none uppercase"
                  />
                </div>
                <button 
                  onClick={handleAdd}
                  className="w-full bg-blue-600 text-white rounded-[1.5rem] py-5 font-display font-black text-xl hover:bg-blue-700 transition-all shadow-xl active:scale-95 relative z-10"
                >
                  DROP PIN NOW
                </button>
                <div className="absolute top-[-20%] right-[-10%] w-32 h-32 bg-blue-600/30 rounded-full blur-3xl opacity-50"></div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-4">
            {points.sort((a,b) => b.verifiedBy.length - a.verifiedBy.length).map(point => (
              <motion.div 
                key={point.id} 
                whileHover={{ x: 8 }}
                className="bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm flex items-center justify-between group hover:shadow-xl transition-all"
              >
                <div className="flex items-center gap-6">
                  <div className={cn(
                    "w-16 h-16 rounded-2xl flex items-center justify-center transition-all",
                    point.status === 'verified' ? "bg-blue-50 text-blue-600" : "bg-gray-50 text-gray-400"
                  )}>
                    {point.status === 'verified' ? <CheckCircle size={28} /> : <MapPin size={28} />}
                  </div>
                  <div>
                    <h5 className="text-xl font-display font-black text-black group-hover:text-blue-600 transition-colors uppercase italic leading-tight">{point.name}</h5>
                    <div className="flex items-center gap-3 mt-2">
                       <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">
                         {point.verifiedBy.length}/3 SQUAD VOUCHERS
                       </span>
                    </div>
                  </div>
                </div>
                
                {point.status === 'pending' && profile && !point.verifiedBy.includes(profile.uid) && (
                  <button 
                    onClick={() => handleVerify(point)}
                    className="bg-black text-white px-6 py-3 rounded-xl font-display font-black text-[10px] tracking-widest hover:bg-blue-600 transition-all active:scale-95 uppercase"
                  >
                    Vouch
                  </button>
                )}
                
                {point.status === 'verified' && (
                  <div className="text-blue-600 bg-blue-50 w-10 h-10 rounded-full flex items-center justify-center">
                    <CheckCircle size={20} />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-blue-600 text-white p-12 rounded-[3.5rem] flex flex-col lg:flex-row items-center justify-between shadow-[0_30px_70px_rgba(37,99,235,0.4)] relative overflow-hidden">
        <div className="relative z-10 space-y-4 max-w-xl text-center lg:text-left">
          <h4 className="text-5xl font-display font-black flex items-center justify-center lg:justify-start gap-4 uppercase italic tracking-tighter">
             <Navigation size={48} className="text-blue-200" />
             CAMPUS OVERLORD
          </h4>
          <p className="text-xl text-blue-100 font-medium leading-relaxed">
            Help the community and earn <span className="text-white font-black">Flash-Skips</span> & <span className="text-white font-black">Elite Badges</span>.
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-2xl p-8 rounded-[2.5rem] border border-white/20 mt-10 lg:mt-0 relative z-10 w-full lg:w-auto">
          <p className="text-[10px] font-display font-black uppercase tracking-[0.3em] text-blue-200 mb-6 text-center">Your Strategy Rank</p>
          <div className="flex items-center justify-center gap-6">
            <span className="text-6xl font-display font-black italic">#142</span>
            <div className="h-2 w-32 bg-white/10 rounded-full overflow-hidden relative">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '65%' }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="bg-white h-full"
              />
            </div>
          </div>
        </div>
        <div className="absolute bottom-[-100px] right-[-100px] w-[500px] h-[500px] bg-white opacity-10 rounded-full blur-[120px]"></div>
      </div>
    </div>
  );
}
